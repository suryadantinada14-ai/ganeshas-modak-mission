import { WORLD, AI, CHARACTER, obstacles, hidingSpots, interactions, getZone } from './engine.js';

const C={bg:'#2b1120',floor:'#f4d7a2',wall:'#6f263d',gold:'#f4c45f',deep:'#3a1424',pink:'#d85874',green:'#557f52',cream:'#fff2d8',blue:'#4e7898',shadow:'rgba(45,16,28,.25)'};
const rr=(c,x,y,w,h,r)=>{c.beginPath();c.roundRect(x,y,w,h,r);c.fill();};
function text(c,s,x,y,size=18,align='center'){c.font=`700 ${size}px system-ui`;c.textAlign=align;c.fillText(s,x,y);}
function glowCircle(c,x,y,r,col){c.save();c.shadowBlur=18;c.shadowColor=col;c.fillStyle=col;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();c.restore();}

function drawFloor(c){
  c.fillStyle=C.floor;c.fillRect(0,0,WORLD.width,WORLD.height);
  c.globalAlpha=.15;c.strokeStyle=C.wall;c.lineWidth=2;
  for(let x=40;x<WORLD.width;x+=80){c.beginPath();c.moveTo(x,0);c.lineTo(x,WORLD.height);c.stroke();}
  for(let y=40;y<WORLD.height;y+=80){c.beginPath();c.moveTo(0,y);c.lineTo(WORLD.width,y);c.stroke();}c.globalAlpha=1;
  const zones=[['PUJA ROOM',40,55],['STORAGE',560,55],['SECRET PASSAGE',1100,55],['COURTYARD',50,545],['LIVING ROOM',570,545],['KITCHEN',1110,545]];
  c.fillStyle='rgba(94,31,51,.11)';zones.forEach(([s,x,y])=>text(c,s,x,y,18,'left'));
}
function drawRangoli(c,x,y,done){
  c.save();c.translate(x,y);for(let i=0;i<12;i++){c.rotate(Math.PI/6);c.fillStyle=[C.pink,C.gold,C.green,C.blue][i%4];c.beginPath();c.ellipse(0,36,14,31,0,0,Math.PI*2);c.fill();}
  c.fillStyle=C.cream;c.beginPath();c.arc(0,0,28,0,Math.PI*2);c.fill();if(done){c.shadowBlur=24;c.shadowColor=C.gold;c.strokeStyle=C.gold;c.lineWidth=7;c.beginPath();c.arc(0,0,70,0,Math.PI*2);c.stroke();}c.restore();
}
function drawDecor(c,celebrate){
  c.strokeStyle=C.green;c.lineWidth=5;c.beginPath();c.moveTo(40,100);c.quadraticCurveTo(800,190,1560,100);c.stroke();
  for(let x=80;x<1560;x+=95){c.fillStyle=x%190?C.pink:C.gold;c.beginPath();c.moveTo(x,104);c.lineTo(x+18,138);c.lineTo(x-18,138);c.closePath();c.fill();}
  drawRangoli(c,280,610,celebrate);
  for(const [x,y] of [[80,450],[470,450],[1080,450],[1540,450],[70,930],[1530,930]]){glowCircle(c,x,y,7,celebrate?'#ffd36a':'#f1a84e');c.fillStyle='#6d412c';c.fillRect(x-8,y+7,16,8);}
}
function drawObstacle(c,o){
  if(o.kind==='wall'){c.fillStyle=C.wall;c.fillRect(o.x,o.y,o.w,o.h);return;}
  c.save();c.fillStyle=o.kind==='shrine'?C.gold:o.kind==='sofa'?'#8e4059':'#8f684d';c.shadowColor=C.shadow;c.shadowBlur=12;rr(c,o.x,o.y,o.w,o.h,12);c.restore();
  if(o.kind==='shrine'){c.fillStyle=C.deep;text(c,'ॐ',o.x+o.w/2,o.y+46,30);}
}
function drawModak(c,item,t){
  const glow=item.type==='golden'||item.type==='secret';c.save();c.translate(item.x,item.y);const s=1+Math.sin(t*4+item.x)*.05;c.scale(s,s);if(glow){c.shadowBlur=22;c.shadowColor=C.gold;}
  c.fillStyle=item.type==='secret'?'#fff0a8':item.type==='special'?'#f4a8a0':C.gold;c.beginPath();c.moveTo(0,-22);c.bezierCurveTo(-5,-12,-22,-8,-19,8);c.quadraticCurveTo(0,29,19,8);c.bezierCurveTo(22,-8,5,-12,0,-22);c.fill();
  c.strokeStyle='#9a5b31';c.lineWidth=2;for(let i=-10;i<=10;i+=10){c.beginPath();c.moveTo(0,-17);c.quadraticCurveTo(i,0,i,12);c.stroke();}c.restore();
}
function drawPickup(c,item,t){if(item.kind==='modak')return drawModak(c,item,t);c.save();c.translate(item.x,item.y);c.shadowBlur=10;c.shadowColor=C.gold;c.fillStyle=item.kind==='flowers'?C.pink:item.kind==='durva'?C.green:item.kind==='diyas'?C.gold:C.blue;c.beginPath();c.arc(0,0,14+Math.sin(t*3)*2,0,Math.PI*2);c.fill();c.fillStyle=C.deep;text(c,item.kind==='flowers'?'✿':item.kind==='durva'?'❧':item.kind==='diyas'?'✦':'◆',0,6,17);c.restore();}
function drawHide(c,h){c.save();c.globalAlpha=.25;c.strokeStyle=C.green;c.lineWidth=3;c.setLineDash([8,8]);c.beginPath();c.arc(h.x,h.y,h.r*.55,0,Math.PI*2);c.stroke();c.restore();}
function drawInteract(c,i,game){c.save();c.globalAlpha=.6;c.fillStyle=i.type==='noise'?C.gold:i.type==='switchMushak'?C.green:C.blue;c.beginPath();c.arc(i.x,i.y,10,0,Math.PI*2);c.fill();c.restore();if(i.id==='festival-box'&&game.puzzle.box)text(c,'✓',i.x,i.y+6,18);}
function drawGanesha(c,p,t,hidden=false){
  c.save();c.translate(p.x,p.y);c.globalAlpha=hidden?.28:1;const bob=Math.sin(p.anim||t*2)*2;c.translate(0,bob);
  c.fillStyle='#e98f6f';c.beginPath();c.arc(0,-8,18,0,Math.PI*2);c.fill();
  c.fillStyle='#f0a37f';c.beginPath();c.ellipse(0,10,13,24,0,0,Math.PI*2);c.fill();
  c.beginPath();c.ellipse(-17,-8,12,17,-.5,0,Math.PI*2);c.ellipse(17,-8,12,17,.5,0,Math.PI*2);c.fill();
  c.strokeStyle='#f0a37f';c.lineWidth=8;c.lineCap='round';c.beginPath();c.moveTo(2,2);c.quadraticCurveTo(8,18,-3,26);c.stroke();
  c.fillStyle=C.gold;c.beginPath();c.moveTo(-13,-25);c.lineTo(0,-42);c.lineTo(13,-25);c.closePath();c.fill();
  c.fillStyle='#7a263d';c.fillRect(-16,16,32,18);c.fillStyle='#2e1721';c.beginPath();c.arc(-6,-10,2.5,0,7);c.arc(6,-10,2.5,0,7);c.fill();c.restore();
}
function drawMushak(c,m,t,active){c.save();c.translate(m.x,m.y);const bob=Math.sin(t*7)*1.5;c.translate(0,bob);c.fillStyle=active?'#4b5564':'#69707c';c.beginPath();c.ellipse(0,0,14,9,0,0,7);c.ellipse(11,-6,7,7,0,0,7);c.fill();c.strokeStyle='#69707c';c.lineWidth=2;c.beginPath();c.moveTo(-12,1);c.quadraticCurveTo(-28,-8,-30,7);c.stroke();c.fillStyle='#111';c.beginPath();c.arc(13,-7,1.5,0,7);c.fill();c.restore();}
function drawParvati(c,p,t){c.save();c.translate(p.x,p.y);c.rotate(0);const bob=Math.sin(t*3)*1.5;c.translate(0,bob);c.fillStyle='#c94f68';c.beginPath();c.moveTo(-23,28);c.lineTo(-14,-7);c.quadraticCurveTo(0,-27,14,-7);c.lineTo(23,28);c.closePath();c.fill();c.fillStyle='#d99772';c.beginPath();c.arc(0,-21,15,0,7);c.fill();c.fillStyle=C.gold;c.beginPath();c.arc(0,-38,11,0,Math.PI);c.fill();c.fillStyle='#30151c';c.beginPath();c.arc(-5,-23,2,0,7);c.arc(5,-23,2,0,7);c.fill();c.restore();}
function drawVision(c,p){if(p.state===AI.CALM&&p.awareness<.05)return;c.save();c.translate(p.x,p.y);c.rotate(p.dir);c.fillStyle=p.state===AI.ALERT?'rgba(214,58,68,.16)':'rgba(238,183,73,.13)';c.beginPath();c.moveTo(0,0);c.arc(0,0,330,-.78,.78);c.closePath();c.fill();c.restore();}

export function render(canvas,ctx,game,time=0){
  const dpr=Math.min(devicePixelRatio||1,2);const rect=canvas.getBoundingClientRect();const w=Math.max(320,rect.width),h=Math.max(240,rect.height);
  if(canvas.width!==Math.floor(w*dpr)||canvas.height!==Math.floor(h*dpr)){canvas.width=Math.floor(w*dpr);canvas.height=Math.floor(h*dpr);}
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
  const focus=game.character===CHARACTER.ganesha?game.player:game.mushak;const scale=Math.min(w/900,h/590);const vw=w/scale,vh=h/scale;
  const camX=Math.max(0,Math.min(WORLD.width-vw,focus.x-vw/2)),camY=Math.max(0,Math.min(WORLD.height-vh,focus.y-vh/2));
  ctx.save();ctx.scale(scale,scale);ctx.translate(-camX,-camY);drawFloor(ctx);drawDecor(ctx,game.celebration);
  drawVision(ctx,game.parvati);obstacles.forEach(o=>drawObstacle(ctx,o));hidingSpots.forEach(h=>drawHide(ctx,h));interactions.forEach(i=>drawInteract(ctx,i,game));
  for(const n of game.noise){ctx.save();ctx.globalAlpha=Math.max(0,n.life/1.15)*.45;ctx.strokeStyle=C.gold;ctx.lineWidth=4;ctx.beginPath();ctx.arc(n.x,n.y,n.radius*(1-n.life/1.15),0,7);ctx.stroke();ctx.restore();}
  game.collectibles.filter(i=>i.active).forEach(i=>drawPickup(ctx,i,time));drawMushak(ctx,game.mushak,time,game.character===CHARACTER.mushak);drawParvati(ctx,game.parvati,time);drawGanesha(ctx,game.player,time,game.player.hidden);
  for(const p of game.particles){ctx.globalAlpha=Math.max(0,p.life);ctx.fillStyle=C.gold;ctx.beginPath();ctx.arc(p.x,p.y,4,0,7);ctx.fill();}ctx.globalAlpha=1;
  for(const p of game.popups){ctx.globalAlpha=Math.max(0,p.life);ctx.fillStyle=C.deep;text(ctx,p.text,p.x,p.y,17);}ctx.globalAlpha=1;
  if(game.celebration){ctx.save();ctx.globalAlpha=.18+.08*Math.sin(time*4);ctx.fillStyle=C.gold;ctx.fillRect(camX,camY,vw,vh);ctx.restore();}
  ctx.restore();return {zone:getZone(focus.x,focus.y),camera:{x:camX,y:camY,scale}};
}
