export const WORLD = { width: 1600, height: 1000 };
export const CHARACTER = { ganesha: 'ganesha', mushak: 'mushak' };
export const AI = { CALM:'CALM', SUSPICIOUS:'SUSPICIOUS', ALERT:'ALERT', SEARCH:'SEARCH', RETURN:'RETURN' };

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const norm=(x,y)=>{const d=Math.hypot(x,y)||1;return {x:x/d,y:y/d};};
const rectHit=(x,y,r,o)=>x+r>o.x&&x-r<o.x+o.w&&y+r>o.y&&y-r<o.y+o.h;
const pointRect=(x,y,o)=>x>=o.x&&x<=o.x+o.w&&y>=o.y&&y<=o.y+o.h;

export const obstacles = [
  {x:0,y:0,w:1600,h:26,kind:'wall'},{x:0,y:974,w:1600,h:26,kind:'wall'},
  {x:0,y:0,w:26,h:1000,kind:'wall'},{x:1574,y:0,w:26,h:1000,kind:'wall'},
  {x:500,y:0,w:24,h:330,kind:'wall'},{x:500,y:410,w:24,h:240,kind:'wall'},{x:500,y:760,w:24,h:214,kind:'wall'},
  {x:1040,y:0,w:24,h:260,kind:'wall'},{x:1040,y:260,w:24,h:90,kind:'gate'},{x:1040,y:350,w:24,h:300,kind:'wall'},{x:1040,y:760,w:24,h:214,kind:'wall'},
  {x:26,y:470,w:300,h:24,kind:'wall'},{x:405,y:470,w:290,h:24,kind:'wall'},{x:790,y:470,w:240,h:24,kind:'wall'},
  {x:1080,y:470,w:494,h:24,kind:'wall'},
  {x:120,y:120,w:180,h:70,kind:'shrine'},{x:120,y:300,w:90,h:52,kind:'table'},
  {x:610,y:120,w:220,h:72,kind:'shelf'},{x:850,y:300,w:120,h:82,kind:'box'},
  {x:585,y:610,w:220,h:80,kind:'sofa'},{x:840,y:690,w:95,h:150,kind:'pillar'},
  {x:1180,y:610,w:170,h:90,kind:'counter'},{x:1370,y:760,w:130,h:80,kind:'counter'},
  {x:120,y:650,w:120,h:120,kind:'pandal'},{x:310,y:720,w:90,h:150,kind:'display'}
];

export const hidingSpots=[
  {id:'curtain',x:930,y:590,r:58,label:'Curtain'},
  {id:'pillar',x:885,y:640,r:55,label:'Pillar'},
  {id:'display',x:352,y:700,r:60,label:'Festival display'},
  {id:'storage-screen',x:690,y:255,r:58,label:'Flower screen'}
];

export const interactions=[
  {id:'bell',x:1270,y:560,r:52,type:'noise',label:'Ring brass bell'},
  {id:'pot',x:1450,y:690,r:48,type:'noise',label:'Tap metal pot'},
  {id:'festival-box',x:905,y:255,r:68,type:'boxPuzzle',label:'Festival box puzzle'},
  {id:'diya-puzzle',x:385,y:250,r:66,type:'diyaPuzzle',label:'Diya sequence'},
  {id:'rangoli',x:275,y:585,r:75,type:'rangoli',label:'Complete rangoli'},
  {id:'mushak-switch',x:560,y:400,r:70,type:'switchMushak',label:'Switch character'},
  {id:'secret-lever',x:1390,y:280,r:55,type:'secretLever',label:'Tiny passage lever',mushakOnly:true}
];

const baseCollectibles=()=>[
  {id:'m1',kind:'modak',type:'normal',points:10,x:340,y:890,active:true,label:'Normal Modak'},
  {id:'m2',kind:'modak',type:'normal',points:10,x:750,y:885,active:true,label:'Normal Modak'},
  {id:'m3',kind:'modak',type:'special',points:25,x:1470,y:905,active:true,label:'Special Modak'},
  {id:'m4',kind:'modak',type:'golden',points:50,x:960,y:430,active:false,label:'Golden Modak'},
  {id:'m5',kind:'modak',type:'secret',points:100,x:1450,y:180,active:false,label:'Secret Modak'},
  {id:'f1',kind:'flowers',points:20,x:190,y:410,active:true,label:'Flower basket'},
  {id:'f2',kind:'flowers',points:20,x:670,y:410,active:true,label:'Flower basket'},
  {id:'f3',kind:'flowers',points:20,x:1240,y:410,active:true,label:'Flower basket'},
  {id:'d1',kind:'durva',points:20,x:420,y:120,active:true,label:'Durva'},
  {id:'d2',kind:'durva',points:20,x:770,y:230,active:true,label:'Durva'},
  {id:'d3',kind:'durva',points:20,x:1100,y:380,active:true,label:'Durva'},
  {id:'l1',kind:'diyas',points:25,x:95,y:555,active:true,label:'Diya'},
  {id:'l2',kind:'diyas',points:25,x:1010,y:915,active:true,label:'Diya'},
  {id:'c1',kind:'decorations',points:15,x:465,y:900,active:true,label:'Decoration'},
  {id:'c2',kind:'decorations',points:15,x:970,y:410,active:true,label:'Decoration'},
  {id:'c3',kind:'decorations',points:15,x:1510,y:420,active:true,label:'Decoration'}
];

export function createGame(seed=1){
  return {
    seed, phase:'menu', paused:false, elapsed:0, remaining:480, countdownExpired:false,
    score:0, caughtCount:0, stealthBroken:false, character:CHARACTER.ganesha,
    player:{x:210,y:850,r:20,hidden:false,run:false,grace:0,anim:0,checkpoint:{x:210,y:850}},
    mushak:{x:250,y:860,r:12,unlocked:true},
    parvati:{x:1230,y:850,r:22,dir:-Math.PI/2,state:AI.CALM,stateTime:0,awareness:0,target:null,lastKnown:null,patrolIndex:0,path:[],pathIndex:0,pathTarget:null,pathRefresh:0},
    patrol:[{x:1260,y:850},{x:1280,y:560},{x:890,y:560},{x:650,y:820},{x:400,y:560},{x:350,y:350},{x:760,y:360},{x:1160,y:360}],
    collectibles:baseCollectibles(),
    objectives:{modaks:0,flowers:0,durva:0,diyas:0,rangoli:0,decorations:0},
    puzzle:{box:false,diya:false,rangoli:false,secretLever:false,bell:false},
    secretPassage:false,
    noise:[], particles:[], popups:[], messages:[],
    modal:null, celebration:false, completed:false, final:null
  };
}

export function isBlocked(x,y,r=20, character=CHARACTER.ganesha, game=null){
  if(x-r<26||x+r>1574||y-r<26||y+r>974)return true;
  if(character===CHARACTER.mushak){
    // Mushak can slip through the small secret-passage gate, but not phase
    // through ordinary room walls or furniture.
    return obstacles.some(o=>o.kind!=='gate' && rectHit(x,y,r,o));
  }
  return obstacles.some(o=>{
    if(o.kind==='gate' && game?.secretPassage) return false;
    return rectHit(x,y,r,o);
  });
}

export function moveCharacter(game,dx,dy,dt,run=false){
  if(game.phase!=='playing'||game.paused||game.modal||game.completed)return;
  const entity=game.character===CHARACTER.ganesha?game.player:game.mushak;
  if(game.character===CHARACTER.ganesha && game.player.hidden && (dx||dy)) return;
  if(!dx&&!dy){ entity.run=false; return; }
  const n=norm(dx,dy), base=game.character===CHARACTER.ganesha?150:185, speed=base*(run&&game.character===CHARACTER.ganesha?1.65:1);
  const nx=entity.x+n.x*speed*dt, ny=entity.y+n.y*speed*dt;
  if(!isBlocked(nx,entity.y,entity.r,game.character,game)) entity.x=nx;
  if(!isBlocked(entity.x,ny,entity.r,game.character,game)) entity.y=ny;
  entity.run=run; entity.anim+=dt*speed/80;
  if(game.character===CHARACTER.ganesha && run){
    game.stealthBroken=true;
    if((Math.floor(game.elapsed*5)%3)===0) emitNoise(game,entity.x,entity.y,190,'running');
  }
}

export function emitNoise(game,x,y,radius=180,source='noise'){
  const exists=game.noise.some(n=>n.source===source && game.elapsed-n.created<0.25);
  if(!exists) game.noise.push({x,y,radius,source,created:game.elapsed,life:1.15});
  const p=game.parvati;
  if(dist(p,{x,y})<=radius+160 && p.state!==AI.ALERT){
    p.target={x,y}; p.lastKnown={x,y}; p.state=AI.SUSPICIOUS; p.stateTime=0; p.awareness=Math.max(p.awareness,0.35);
  }
}

function segIntersectsRect(a,b,r){
  const steps=Math.max(4,Math.ceil(dist(a,b)/20));
  for(let i=1;i<steps;i++){const t=i/steps,x=a.x+(b.x-a.x)*t,y=a.y+(b.y-a.y)*t;if(pointRect(x,y,r))return true;}
  return false;
}
export function hasLineOfSight(a,b,game){
  return !obstacles.some(o=>{
    if(o.kind==='gate' && game.secretPassage) return false;
    return segIntersectsRect(a,b,o);
  });
}
export function canSeePlayer(game){
  if(game.character!==CHARACTER.ganesha||game.player.hidden||game.player.grace>0)return false;
  const p=game.parvati,g=game.player,d=dist(p,g);
  if(d>330)return false;
  const ang=Math.atan2(g.y-p.y,g.x-p.x),diff=Math.atan2(Math.sin(ang-p.dir),Math.cos(ang-p.dir));
  if(Math.abs(diff)>0.78)return false;
  return hasLineOfSight(p,g,game);
}

const NAV_CELL=40;
const navKey=(c,r)=>`${c},${r}`;
function navPoint(c,r){return {x:c*NAV_CELL+NAV_CELL/2,y:r*NAV_CELL+NAV_CELL/2,c,r};}
function nearestOpenCell(point,radius,game){
  const cols=Math.ceil(WORLD.width/NAV_CELL),rows=Math.ceil(WORLD.height/NAV_CELL);
  const bc=clamp(Math.floor(point.x/NAV_CELL),0,cols-1),br=clamp(Math.floor(point.y/NAV_CELL),0,rows-1);
  for(let ring=0;ring<=3;ring++){
    for(let dr=-ring;dr<=ring;dr++)for(let dc=-ring;dc<=ring;dc++){
      if(ring && Math.max(Math.abs(dc),Math.abs(dr))!==ring)continue;
      const c=bc+dc,r=br+dr;if(c<0||r<0||c>=cols||r>=rows)continue;
      const p=navPoint(c,r);if(!isBlocked(p.x,p.y,radius,CHARACTER.ganesha,game))return p;
    }
  }
  return null;
}
function findPath(start,goal,radius,game){
  const s=nearestOpenCell(start,radius,game),g=nearestOpenCell(goal,radius,game);if(!s||!g)return [];
  const open=[s],came=new Map(),gScore=new Map([[navKey(s.c,s.r),0]]),closed=new Set();
  const dirs=[[1,0,1],[-1,0,1],[0,1,1],[0,-1,1],[1,1,1.414],[1,-1,1.414],[-1,1,1.414],[-1,-1,1.414]];
  const h=(a)=>Math.hypot(a.c-g.c,a.r-g.r);
  while(open.length){
    let best=0,bestF=Infinity;for(let i=0;i<open.length;i++){const k=navKey(open[i].c,open[i].r),f=(gScore.get(k)??Infinity)+h(open[i]);if(f<bestF){bestF=f;best=i;}}
    const cur=open.splice(best,1)[0],ck=navKey(cur.c,cur.r);if(cur.c===g.c&&cur.r===g.r){
      const path=[];let k=ck,node=cur;while(node){path.push({x:node.x,y:node.y});const prev=came.get(k);if(!prev)break;node=prev;k=navKey(node.c,node.r);}return path.reverse();
    }
    closed.add(ck);
    for(const [dc,dr,cost] of dirs){
      const c=cur.c+dc,r=cur.r+dr;if(c<0||r<0)continue;const p=navPoint(c,r);if(p.x>=WORLD.width||p.y>=WORLD.height)continue;
      const pk=navKey(c,r);if(closed.has(pk)||isBlocked(p.x,p.y,radius,CHARACTER.ganesha,game))continue;
      if(dc&&dr){const a=navPoint(cur.c+dc,cur.r),b=navPoint(cur.c,cur.r+dr);if(isBlocked(a.x,a.y,radius,CHARACTER.ganesha,game)||isBlocked(b.x,b.y,radius,CHARACTER.ganesha,game))continue;}
      const tentative=(gScore.get(ck)??Infinity)+cost;if(tentative<(gScore.get(pk)??Infinity)){came.set(pk,cur);gScore.set(pk,tentative);if(!open.some(n=>n.c===c&&n.r===r))open.push(p);}
    }
  }
  return [];
}
function resetPath(entity){entity.path=[];entity.pathIndex=0;entity.pathTarget=null;entity.pathRefresh=0;}
function steer(entity,target,speed,dt,game){
  if(!target)return true;
  const d=dist(entity,target);if(d<18){resetPath(entity);return true;}
  entity.pathRefresh=(entity.pathRefresh||0)-dt;
  const targetMoved=!entity.pathTarget||dist(entity.pathTarget,target)>70;
  if(!entity.path?.length||entity.pathIndex>=entity.path.length||targetMoved||entity.pathRefresh<=0){
    entity.path=findPath(entity,target,entity.r+2,game);entity.pathIndex=Math.min(1,Math.max(0,entity.path.length-1));entity.pathTarget={x:target.x,y:target.y};entity.pathRefresh=.65;
  }
  let waypoint=entity.path?.[entity.pathIndex]||target;
  if(dist(entity,waypoint)<18){
    if(entity.pathIndex<entity.path.length-1){entity.pathIndex++;waypoint=entity.path[entity.pathIndex];}
    else waypoint=target;
  }
  const n=norm(waypoint.x-entity.x,waypoint.y-entity.y);entity.dir=Math.atan2(n.y,n.x);
  const step=speed*dt,nx=entity.x+n.x*step,ny=entity.y+n.y*step;
  if(!isBlocked(nx,entity.y,entity.r,CHARACTER.ganesha,game))entity.x=nx;
  if(!isBlocked(entity.x,ny,entity.r,CHARACTER.ganesha,game))entity.y=ny;
  return dist(entity,target)<22;
}

function updateAI(game,dt){
  const p=game.parvati; p.stateTime+=dt;
  const visible=canSeePlayer(game);
  if(visible){
    p.awareness=clamp(p.awareness+dt*(p.state===AI.ALERT?1.2:0.85),0,1);
    p.lastKnown={x:game.player.x,y:game.player.y};
    if(p.awareness>0.62 && p.state!==AI.ALERT){p.state=AI.ALERT;p.stateTime=0;}
  } else p.awareness=clamp(p.awareness-dt*(p.state===AI.SEARCH?0.08:0.16),0,1);

  if(p.state===AI.CALM){
    const target=game.patrol[p.patrolIndex];
    if(steer(p,target,72,dt,game)) p.patrolIndex=(p.patrolIndex+1)%game.patrol.length;
  } else if(p.state===AI.SUSPICIOUS){
    if(p.target && steer(p,p.target,92,dt,game)){p.state=AI.SEARCH;p.stateTime=0;p.lastKnown=p.target;p.target=null;}
    if(p.stateTime>6){p.state=AI.RETURN;p.stateTime=0;}
  } else if(p.state===AI.ALERT){
    if(visible){steer(p,game.player,125,dt,game);}
    else {p.state=AI.SEARCH;p.stateTime=0;p.target=p.lastKnown;}
    if(dist(p,game.player)<38 && !game.player.hidden && game.player.grace<=0) catchPlayer(game);
  } else if(p.state===AI.SEARCH){
    if(p.target) steer(p,p.target,90,dt,game);
    if(visible){p.state=AI.ALERT;p.stateTime=0;}
    else if(p.stateTime>5.5){p.state=AI.RETURN;p.stateTime=0;p.target=null;}
  } else if(p.state===AI.RETURN){
    const target=game.patrol[p.patrolIndex];
    if(steer(p,target,75,dt,game)||p.stateTime>5){p.state=AI.CALM;p.stateTime=0;p.awareness=0;}
  }
}

function collect(game,item){
  if(!item.active)return;
  item.active=false; game.score+=item.points;
  if(item.kind==='modak'){
    game.objectives.modaks++; game.player.checkpoint={x:game.player.x,y:game.player.y};
  } else game.objectives[item.kind]++;
  game.popups.push({x:item.x,y:item.y,text:`+${item.points} ${item.kind==='modak'?'MODAK':'FESTIVAL'}`,life:1.2});
  game.particles.push(...Array.from({length:12},(_,i)=>({x:item.x,y:item.y,vx:Math.cos(i/12*Math.PI*2)*50,vy:Math.sin(i/12*Math.PI*2)*50,life:.8})));
  game.messages.push(`${item.label} collected`);
}

function updateCollectibles(game){
  const e=game.character===CHARACTER.ganesha?game.player:game.mushak;
  for(const item of game.collectibles){
    if(item.active && dist(e,item)<(game.character===CHARACTER.mushak?24:34)){
      if(item.id==='m5' && game.character!==CHARACTER.mushak)continue;
      collect(game,item);
    }
  }
}

export function nearestInteraction(game){
  const e=game.character===CHARACTER.ganesha?game.player:game.mushak;
  let best=null,bd=Infinity;
  for(const i of interactions){
    if(i.mushakOnly&&game.character!==CHARACTER.mushak)continue;
    const d=dist(e,i); if(d<i.r&&d<bd){best=i;bd=d;}
  }
  const hide=hidingSpots.find(h=>dist(game.player,h)<h.r);
  return {interaction:best,hide};
}

export function interact(game){
  if(game.phase!=='playing'||game.paused||game.completed)return null;
  const {interaction}=nearestInteraction(game); if(!interaction)return null;
  if(interaction.type==='noise'){
    emitNoise(game,interaction.x,interaction.y,interaction.id==='bell'?430:300,interaction.id);
    if(interaction.id==='bell'&&!game.puzzle.bell){game.puzzle.bell=true;game.score+=30;game.messages.push('Bell distraction mastered +30');}
    return {type:'noise',id:interaction.id};
  }
  if(interaction.type==='switchMushak'){ switchCharacter(game); return {type:'switch'}; }
  if(interaction.type==='boxPuzzle'&&!game.puzzle.box){game.modal={type:'boxPuzzle',sequence:[]};return game.modal;}
  if(interaction.type==='diyaPuzzle'&&!game.puzzle.diya){game.modal={type:'diyaPuzzle',sequence:[]};return game.modal;}
  if(interaction.type==='rangoli'&&!game.puzzle.rangoli){game.modal={type:'rangoli',sequence:[]};return game.modal;}
  if(interaction.type==='secretLever'&&!game.puzzle.secretLever){
    game.puzzle.secretLever=true;game.secretPassage=true;game.score+=75;
    const m=game.collectibles.find(x=>x.id==='m5');if(m)m.active=true;
    game.messages.push('Secret passage opened +75');return {type:'lever'};
  }
  return null;
}

export function toggleHide(game){
  if(game.character!==CHARACTER.ganesha||game.phase!=='playing')return false;
  if(game.player.hidden){game.player.hidden=false;game.messages.push('You leave hiding');return true;}
  const {hide}=nearestInteraction(game); if(hide && game.parvati.state!==AI.ALERT){game.player.hidden=true;game.player.run=false;game.messages.push('HIDDEN');return true;}
  game.messages.push(game.parvati.state===AI.ALERT?'Break line of sight before hiding':'Move closer to a hiding spot');return false;
}

export function switchCharacter(game){
  if(game.phase!=='playing')return;
  if(game.character===CHARACTER.ganesha){game.mushak.x=game.player.x+25;game.mushak.y=game.player.y+10;game.character=CHARACTER.mushak;}
  else { if(dist(game.mushak,game.player)>190){game.messages.push('Return closer to Ganesha to switch back');return;} game.character=CHARACTER.ganesha; }
  game.messages.push(game.character===CHARACTER.mushak?'Mushak is scouting':'Back to Ganesha');
}

export function solvePuzzleStep(game,choice){
  if(!game.modal)return {done:false,ok:false};
  const m=game.modal;m.sequence.push(choice);
  const configs={
    boxPuzzle:{target:['diya','flower','durva'],score:80},
    diyaPuzzle:{target:['east','south','west','north'],score:90},
    rangoli:{target:['saffron','pink','green','blue'],score:150}
  };
  const c=configs[m.type]; if(!c)return {done:false,ok:false};
  const idx=m.sequence.length-1;
  if(m.sequence[idx]!==c.target[idx]){
    emitNoise(game,game.player.x,game.player.y,260,`${m.type}-mistake`);m.sequence=[];game.messages.push('That sequence made a little noise');return {done:false,ok:false,reset:true};
  }
  if(m.sequence.length===c.target.length){
    game.score+=c.score;game.puzzle[m.type==='boxPuzzle'?'box':m.type==='diyaPuzzle'?'diya':'rangoli']=true;
    if(m.type==='boxPuzzle'){const x=game.collectibles.find(v=>v.id==='m4');if(x)x.active=true;}
    if(m.type==='diyaPuzzle')game.secretPassage=true;
    if(m.type==='rangoli')game.objectives.rangoli=1;
    game.modal=null;game.messages.push(`${m.type==='rangoli'?'Perfect rangoli':'Puzzle solved'} +${c.score}`);return {done:true,ok:true};
  }
  return {done:false,ok:true};
}

export function closeModal(game){game.modal=null;}

export function catchPlayer(game){
  if(game.completed)return;
  game.caughtCount++;game.score=Math.max(0,game.score-50);game.remaining=Math.max(0,game.remaining-10);
  game.player.x=game.player.checkpoint.x;game.player.y=game.player.checkpoint.y;game.player.hidden=false;game.player.grace=4;
  game.character=CHARACTER.ganesha;
  Object.assign(game.parvati,{state:AI.RETURN,stateTime:0,awareness:0,target:null,x:1230,y:850,path:[],pathIndex:0,pathTarget:null,pathRefresh:0});
  game.modal={type:'caught'};game.messages.push('Maa Parvati caught the mischief — 10 seconds, -50 points');
}

export function continueAfterCatch(game){if(game.modal?.type==='caught')game.modal=null;}

function allObjectives(game){
  const o=game.objectives;return o.modaks>=5&&o.flowers>=3&&o.durva>=3&&o.diyas>=2&&o.rangoli>=1&&o.decorations>=3;
}
function finish(game){
  if(game.completed)return;game.completed=true;game.celebration=true;game.phase='celebration';
  const stealthBonus=game.caughtCount===0?200:Math.max(0,100-game.caughtCount*25);
  const timeBonus=Math.max(0,Math.round(game.remaining));
  const festivalBonus=500;game.score+=stealthBonus+timeBonus+festivalBonus;
  const rating=game.score>=1200?'MODAK MASTER':game.score>=950?'FESTIVAL HERO':game.score>=700?'PUJA PRO':'MODAK NOVICE';
  game.final={score:game.score,time:Math.round(game.elapsed),remaining:Math.round(game.remaining),stealthBonus,timeBonus,festivalBonus,rating,caught:game.caughtCount};
}

export function update(game,dt){
  if(game.phase!=='playing'||game.paused||game.modal||game.completed)return;
  dt=Math.min(dt,0.05);game.elapsed+=dt;game.remaining=Math.max(0,game.remaining-dt);if(game.remaining===0)game.countdownExpired=true;
  game.player.grace=Math.max(0,game.player.grace-dt);
  updateCollectibles(game);updateAI(game,dt);
  game.noise.forEach(n=>n.life-=dt);game.noise=game.noise.filter(n=>n.life>0);
  game.particles.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;});game.particles=game.particles.filter(p=>p.life>0);
  game.popups.forEach(p=>{p.y-=25*dt;p.life-=dt;});game.popups=game.popups.filter(p=>p.life>0);
  if(allObjectives(game))finish(game);
}

export function startGame(game){game.phase='playing';game.modal=null;}
export function pauseGame(game,v=!game.paused){game.paused=v;}
export function restartGame(){const g=createGame();g.phase='playing';return g;}
export function formatTime(sec){sec=Math.max(0,Math.round(sec));return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;}
export function getZone(x,y){if(y<470){if(x<520)return'PUJA ROOM';if(x<1060)return'STORAGE AREA';return'SECRET PASSAGE';}if(x<520)return'FESTIVAL COURTYARD';if(x<1060)return'LIVING ROOM';return'KITCHEN';}
